<?php
/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       catchplugins.com
 * @since      1.0.0
 *
 * @package    Catch_Instagram_Feed_Gallery_Widget
 * @subpackage Catch_Instagram_Feed_Gallery_Widget/public/partials
 */

?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div style="height: 200px; width: 500px; background: orange;"></div>

<?php
